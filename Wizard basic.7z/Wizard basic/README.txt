This is a fan remake of Wizard and Princess by Douglas Crookes. The original game 
was created by Ken and Roberta Williams.

This version was developed in GW-Basic. The executable of the file is 
wizard.bas but the game uses two other .bas files to run, as well as a number
of image files. All files will need to be downloaded for the game to work.

To run the game, one would obviously need GW-Basic as well as Dosbox or a similar
dos emulator.

The game is provided free, but if you like the game please consider purchasing the
original game.

